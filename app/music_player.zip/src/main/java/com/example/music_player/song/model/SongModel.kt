package com.example.music_player.song.model

class SongModel(var title: String, var artist: String, var urlArtistPhoto: String) {

}